const env={
    server_listen:3000,
    version:"1.0.0",
    api_key:"redeemo",
};
module.exports=env;